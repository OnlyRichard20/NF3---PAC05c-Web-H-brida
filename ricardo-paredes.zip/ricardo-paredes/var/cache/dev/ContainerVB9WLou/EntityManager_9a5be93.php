<?php

namespace ContainerVB9WLou;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHoldercfa33 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializercf323 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesc1f05 = [
        
    ];

    public function getConnection()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getConnection', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getMetadataFactory', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getExpressionBuilder', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'beginTransaction', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->beginTransaction();
    }

    public function getCache()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getCache', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getCache();
    }

    public function transactional($func)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'transactional', array('func' => $func), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->transactional($func);
    }

    public function commit()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'commit', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->commit();
    }

    public function rollback()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'rollback', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getClassMetadata', array('className' => $className), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'createQuery', array('dql' => $dql), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'createNamedQuery', array('name' => $name), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'createQueryBuilder', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'flush', array('entity' => $entity), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'clear', array('entityName' => $entityName), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->clear($entityName);
    }

    public function close()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'close', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->close();
    }

    public function persist($entity)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'persist', array('entity' => $entity), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'remove', array('entity' => $entity), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'refresh', array('entity' => $entity), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'detach', array('entity' => $entity), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'merge', array('entity' => $entity), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getRepository', array('entityName' => $entityName), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'contains', array('entity' => $entity), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getEventManager', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getConfiguration', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'isOpen', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getUnitOfWork', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getProxyFactory', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'initializeObject', array('obj' => $obj), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'getFilters', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'isFiltersStateClean', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'hasFilters', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return $this->valueHoldercfa33->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializercf323 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHoldercfa33) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHoldercfa33 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHoldercfa33->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, '__get', ['name' => $name], $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        if (isset(self::$publicPropertiesc1f05[$name])) {
            return $this->valueHoldercfa33->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercfa33;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldercfa33;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, '__set', array('name' => $name, 'value' => $value), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercfa33;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldercfa33;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, '__isset', array('name' => $name), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercfa33;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHoldercfa33;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, '__unset', array('name' => $name), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldercfa33;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHoldercfa33;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, '__clone', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        $this->valueHoldercfa33 = clone $this->valueHoldercfa33;
    }

    public function __sleep()
    {
        $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, '__sleep', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;

        return array('valueHoldercfa33');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializercf323 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializercf323;
    }

    public function initializeProxy() : bool
    {
        return $this->initializercf323 && ($this->initializercf323->__invoke($valueHoldercfa33, $this, 'initializeProxy', array(), $this->initializercf323) || 1) && $this->valueHoldercfa33 = $valueHoldercfa33;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHoldercfa33;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHoldercfa33;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
