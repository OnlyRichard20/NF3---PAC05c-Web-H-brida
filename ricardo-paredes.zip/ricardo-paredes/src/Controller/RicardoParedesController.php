<?php
    namespace App\Controller;
    use Symfony\Component\Routing\Annotation\Route;
    use Symfony\Component\HttpFoundation\Response;

    class RicardoParedesController{
        public function Ramos(){
            /**
             * @Route("/")
             */
            return new Response('Oh! Funciona!');
        }
        /**
         * @Route("/news/noticia-del-dia-sobre-asteroides")
         */
        public function show()
        {
            return new Response('Algo para mostrar...!');
        }
    }
